import express from "express";
import bodyParser from "body-parser";
import pg from "pg";
import bcrypt from "bcrypt";
import { GoogleGenerativeAI } from "@google/generative-ai";



const app = express();
const port = process.env.PORT || 3000;
const saltRounds = 10;
const GEMINI_API_KEY = "AIzaSyBrJumpvjRHR347nu-UB5wXYXiM0tFzQsk";

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); 
app.use(express.static("public")); 
const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "O-Agronect", 
  password: "vino",
  port: 5432,
});
db.connect();
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
const mentalHealthKeywords =  [
  "organic farming", "sustainable agriculture", "crop rotation", "soil health","cecember","month","grow",
  "composting", "pest management", "natural fertilizers", "crop diversity",
  "irrigation techniques", "water conservation", "eco-friendly practices",
  "agricultural innovation", "biodiversity", "cover crops", "green manure",
  "mulching", "farm-to-table", "agroforestry", "organic certification",
  "carbon farming", "greenhouse farming", "integrated pest management (IPM)",
  "sustainable yields", "farm management", "regenerative farming",
  "zero-budget farming", "vermicomposting", "soil fertility", 
  "farm equipment", "livestock management", "renewable resources",
  "local produce", "climate-resilient farming", "precision agriculture",
  "farm economics", "seed selection", "companion planting", "crop residue",
  "biological pest control", "aquaponics", "hydroponics", "drip irrigation",
  "agriculture technology", "permaculture", "farmer welfare",
  "market linkages", "food security", "supply chain in agriculture",
  "weather monitoring", "poultry farming", "dairy farming", 
  "harvesting techniques", "agricultural policies", "government schemes",
  "fertilizer recommendations", "organic seeds", "soil testing",
  "nutrient management", "weed control", "post-harvest processing","organic","manure","make",
  "climate-smart farming", "sustainable food systems", "eco-agriculture",
  "crop protection", "farm tools", "agriculture marketing", "plant","paddy","soil",
  "farmer empowerment", "agribusiness", "horticulture", "soil erosion control",
  "food sovereignty", "irrigation efficiency", "climate adaptation",
  "plant diseases", "yield improvement", "agroecology", "self-sufficient farming",
  "renewable energy in farming", "precision irrigation", 
  "direct-to-consumer sales", "agripreneurship", "seed banks", "organic pesticides",
  "eco-friendly farming", "soil carbon sequestration", "affordable farming solutions",
  "livelihood improvement", "crop insurance", "digital farming tools",
  "farming analytics", "remote sensing in agriculture", "satellite imagery for farming",
  "agriculture machinery", "farmer networks", "seasonal farming", "rainwater harvesting",
  "agriculture research", "crop improvement", "organic farming benefits", "farmer rights",
  "agro-tourism", "sustainable irrigation", "agri-tech startups", "urban farming",
  "vertical farming", "crop resilience", "micro-irrigation", "community-supported agriculture (CSA)",
  "organic farming techniques", "smallholder farming", "biofertilizers",
  "drone technology in agriculture", "water harvesting structures", "plant breeding",
  "soil microbiology", "crop disease prediction", "natural pest repellents",
  "farm productivity", "renewable farming practices", "sustainable packaging",
  "food traceability", "digital marketplaces for farmers", "blockchain in agriculture",
  "genetically modified organisms (GMOs)", "precision sowing", "agricultural drones",
  "organic produce market", "ecosystem services", "agriculture export policies",
  "smart farming", "agricultural biodiversity", "plant propagation",
  "crop adaptation strategies", "land reclamation", "subsidized agriculture programs",
  "sustainable livelihoods", "farmer cooperatives", "carbon-neutral farming",
  "agri-sensors", "farm waste recycling", "seasonal crop planning",
  "green technology in farming", "livestock feed innovation", "bee farming",
  "renewable energy solutions for farming", "digital extension services",
  "farmer education programs", "agri-policy reforms", "soil organic matter",
  "crop climate resilience", "integrated water management"
];


function isMentalHealthRelated(message) {
  const messageLower = message.toLowerCase();
  return mentalHealthKeywords.some(keyword => messageLower.includes(keyword));
}

const empathyPhrases = {  cropHealth: [
  "Your dedication to crop care really shows in the results.",
  "Managing pests effectively is no small feat—great job!",
  "It's inspiring to see how you nurture your fields with care.",
  "A thriving crop is always a reflection of hard work.",
  "Let's discuss ways to keep your crops healthy throughout the season.",
  "Your commitment to sustainable farming is commendable.",
  "You’re doing an excellent job maintaining soil fertility for better yields.",
  "Your crops sound like they’re thriving—what’s your secret?",
  "Crop health is the foundation of any farm. You’re on the right track!"
],
weatherImpact: [
  "Dealing with unexpected weather can be overwhelming, but you’re resilient.",
  "Every farmer faces weather challenges—let's find solutions together.",
  "Rain or shine, your hard work always shines through.",
  "The weather can be a tough opponent, but you’re stronger.",
  "Let's explore techniques to protect your crops from unpredictable weather.",
  "Adapting to weather changes is a skill, and you're mastering it.",
  "Extreme weather can test any farmer, but you’ve got this!",
  "Your idea of using drip irrigation to counter drought is brilliant!",
  "Weather conditions may fluctuate, but your determination doesn’t."
],
marketTrends: [
  "Navigating the market is challenging, but you’re on top of it.",
  "Let’s strategize ways to maximize your profits this season.",
  "Market fluctuations are tricky, but your focus is impressive.",
  "It's excellent that you're looking for new opportunities in the market.",
  "Staying informed about trends shows your commitment to success.",
  "Exploring direct-to-consumer sales could be a game-changer for you.",
  "Let's talk about diversifying your crops for more stable returns.",
  "Market access is crucial; you’re smart to prioritize it.",
  "The market evolves, but your adaptability ensures you thrive."
],
livestockManagement: [
  "Caring for your livestock shows your dedication as a farmer.",
  "Healthy animals are a sign of excellent livestock management.",
  "It’s not easy to balance feed, health, and productivity, but you’re doing great.",
  "Your passion for animal welfare is truly admirable.",
  "Keeping livestock healthy during tough times is an incredible achievement.",
  "Let’s ensure your herd stays strong and productive.",
  "You’re doing a remarkable job supporting your animals’ well-being.",
  "It’s inspiring to see how much effort you put into livestock care.",
  "Strong livestock management is key to a thriving farm."
],
farmOperations: [
  "Your efforts to modernize farm operations are impressive.",
  "It’s great to see you keeping everything organized and efficient.",
  "Streamlined operations always lead to better yields—keep it up!",
  "Investing in sustainable equipment is a step towards long-term success.",
  "Your attention to detail in planning is commendable.",
  "Maintenance is critical—great job staying on top of it.",
  "You’re setting an excellent example for farm management practices.",
  "Your innovative approach to daily tasks is inspiring.",
  "Running a farm efficiently is no small task, but you’re excelling!"
],  generalAdvice: [
  "Your vision for the farm is inspiring. Let’s make it a reality.",
  "Agriculture is evolving, and you’re evolving with it—well done!",
  "Every challenge is an opportunity; let’s tackle it together.",
  "Modern techniques could complement your already effective methods.",
  "Your enthusiasm for farming is contagious—keep up the great work.",
  "It’s always a pleasure to support someone so dedicated to their craft.",
  "You’re on the right path to creating a sustainable future.",
  "Your openness to learning new practices is admirable.",
  "Your hard work is paving the way for better farming practices."
],
}
function analyzeAgriculturalContext(message) {
  if (
    message.includes("healthy crop") ||
    message.includes("pests under control") ||
    message.includes("good growth")
  ) {
    return "cropHealth";
  } else if (
    message.includes("drought") ||
    message.includes("flood") ||
    message.includes("weather problem") ||
    message.includes("irrigation")
  ) {
    return "weatherImpact";
  } else if (
    message.includes("market price") ||
    message.includes("selling produce") ||
    message.includes("pricing trends") ||
    message.includes("demand")
  ) {
    return "marketTrends";
  } else if (
    message.includes("livestock") ||
    message.includes("animal health") ||
    message.includes("feed management")
  ) {
    return "livestockManagement";
  } else if (
    message.includes("operations") ||
    message.includes("tools") ||
    message.includes("machinery") ||
    message.includes("task scheduling")
  ) {
    return "farmOperations";
  }
  return "generalAdvice";
}


app.get("/", (req, res) => {
  res.render("home.ejs");
});

app.get("/login", (req, res) => {
  res.render("login.ejs");
});

app.get("/register", (req, res) => {
  res.render("register.ejs");
});

app.post("/register", async (req, res) => {
  const email = req.body.username;
  const password = req.body.password;
  const gender = req.body.gender;
  const mobile = req.body.mobile;
  const age = req.body.age;

  try {
    const checkResult = await db.query("SELECT * FROM users WHERE email = $1", [email]);

    if (checkResult.rows.length > 0) {
      res.send("Email already exists. Try logging in.");
    } else {
      bcrypt.hash(password, saltRounds, async (err, hash) => {
        if (err) {
          console.error("Error hashing password:", err);
        } else {
          console.log("Hashed Password:", hash);
          await db.query(
            "INSERT INTO users (email, password, gender, mobile, age) VALUES ($1, $2, $3, $4, $5)",
            [email, hash, gender, mobile, age]
          );
          res.render("secrets.ejs");
        }
      });
    }
  } catch (err) {
    console.log(err);
  }
});


app.post("/login", async (req, res) => {
  const email = req.body.username;
  const loginPassword = req.body.password;

  try {
    const result = await db.query("SELECT * FROM users WHERE email = $1", [email]);
    if (result.rows.length > 0) {
      const user = result.rows[0];
      const storedHashedPassword = user.password;
    
      bcrypt.compare(loginPassword, storedHashedPassword, (err, result) => {
        if (err) {
          console.error("Error comparing passwords:", err);
        } else {
          if (result) {
            res.render("secrets.ejs");
          } else {
            res.send("Incorrect Password");
          }
        }
      });
    } else {
      res.send("User not found");
    }
  } catch (err) {
    console.log(err);
  }
});




app.get('/forgot', (req, res) => {
  res.render('forgot.ejs');
});
app.post('/forgot', (req, res) => {
  const { email } = req.body;
  res.send('A password reset link has been sent to your email address.');
});


app.post("/chat", async (req, res) => {
  const userMessage = req.body.message;
  const language = req.body.language || "english";
  const userId = req.body.userId; 
  let msg = userMessage + " Note: the response should be in " + language;

  if (!isMentalHealthRelated(userMessage)) {
    return res.json({ reply: "This chatbot is designed to assist with Agricuilture/Farming inquiries. Please ask about topics related to that." });
  }

  try {
    const result = await model.generateContent(msg);
    const { response: { candidates } } = result;

    if (candidates && candidates.length > 0) {
      const storyCandidate = candidates[0];
      if (storyCandidate.content && storyCandidate.content.parts && storyCandidate.content.parts.length > 0) {
        let chatReply = storyCandidate.content.parts.map(part => part.text).join(" ");
        chatReply = chatReply.replace(/\*/g, '').replace(/[\n\r]+/g, ' ').replace(/\s+/g, ' ').trim();
        const greetings = ["Hi there!", "Hello!", "Hey!", "Greetings!"];
        const empathyPhrases = ["I totally get that.", "That's interesting!", "I see what you mean.", "Let me think about that for a moment."];
        const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
        const randomEmpathy = empathyPhrases[Math.floor(Math.random() * empathyPhrases.length)];
        chatReply = `${randomGreeting} ${randomEmpathy} ${chatReply}`;

        res.json({ reply: chatReply });
      } else {
        res.json({ reply: "I didn't quite catch that. Could you try again?" });
      }
    } else {
      res.json({ reply: "I couldn't find the right words. Can you rephrase?" });
    }
  } catch (error) {
    console.error("Error generating content:", error);
    res.status(500).json({ error: "Oops, something went wrong! Let me try again." });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
